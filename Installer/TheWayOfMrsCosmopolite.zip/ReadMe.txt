TheWayOfMrsCosmopolite
Version 2.042
13/09/2018

All situations, places and characters were developed by Sir Terry Pratchett OBE.

This application was developed by Dan Ladle �2018

To install this application, run Setup.exe, it will create the progam and add a shortcut into your Start Menu.

To run the application, choose TheWayOfMrsCosmopolite from the Start Menu.

This work is not licensed in any way, shape or form, feel free to reverse engineer it, hack it about or generally play with it as much as you like.

#GNUTerryPratchett


Ps I can't afford the (at least) $99 for a code signing certificate, so when you install the software you will have to accept that it is not digitally signed. Sorry!
